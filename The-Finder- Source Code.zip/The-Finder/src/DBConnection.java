
import com.mysql.jdbc.Connection;
import java.sql.*;
import java.lang.*;
import javax.swing.JOptionPane;
import java.text.*;
//import com.mysql.jdbc.DriverManager;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Acer
 */
public class DBConnection {
    public void getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/the-finder","root","123");
            System.out.println("connected....");
        }catch(Exception e){
            System.out.println("Error in db connection");
            e.printStackTrace();
        }
    }
    public static void main (String[] args){
        DBConnection myDB = new DBConnection();
        myDB.getConnection();
    }
}

   
